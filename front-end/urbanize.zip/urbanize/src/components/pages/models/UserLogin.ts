interface UserLogin {
    id: number;
    nomeCompleto: string;
    usuario: string;
    tipo: string;
    foto: string;
    senha: string;
    token: string;
    bio: string;
    endereco: string;
}

export default UserLogin;