interface Tema{
    id: number;
    descricao: string;
    palavraChave: string;
    tema: string;
}

export default Tema;