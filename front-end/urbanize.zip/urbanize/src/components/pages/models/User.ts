interface User {
    id: number;
    nomeCompleto: string;
    usuario: string;
    tipo: string;
    foto: string;
    senha: string;
    bio: string;
    endereco: string;
}

export default User;